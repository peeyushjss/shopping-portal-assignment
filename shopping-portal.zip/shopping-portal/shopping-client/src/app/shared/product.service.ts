import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Product } from './product.model';

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  readonly rootUrl = "http://localhost:8000/api/";

  constructor(private http: HttpClient) { }

  /* Method for getting cookie */
  getCokie() {
    const value = document.cookie,
      parts = value.split(`; token=`);
    if (parts.length === 2)
      return parts.pop().split(';').shift();
  }

  /* placeOrder service called from placeOrder method in order component */
  placeOrder(product: Product) {

    let header = {
      headers: new HttpHeaders()
        .set('Authorization', this.getCokie())
    }

    const body: Product = {
      name: product.name,
      price: product.price
    }
    return this.http.post(this.rootUrl + 'order', body, header);
  }

}
