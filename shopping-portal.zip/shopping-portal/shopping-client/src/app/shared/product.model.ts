export class Product {
    name: string;
    price: number;
}