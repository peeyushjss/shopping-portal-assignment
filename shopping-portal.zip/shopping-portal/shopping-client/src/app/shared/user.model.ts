export class User {
    name: string;
    email: string;
    password: string;
    mobile: string;
    address: string;
}

export class UserLogin {
    email: string;
    password: string;
}