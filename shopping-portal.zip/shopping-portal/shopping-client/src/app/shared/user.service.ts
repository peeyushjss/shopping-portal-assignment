import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { User } from "../shared/user.model";
import { UserLogin } from "../shared/user.model";

@Injectable({
  providedIn: 'root'
})
export class UserService {

  readonly rootUrl = "http://localhost:8000/api/";

  constructor(private http: HttpClient) { }

  /* registerUser service called from registerUser method in register component */
  registerUser(user: User) {
    const body: User = {
      name: user.name,
      email: user.email,
      password: user.password,
      address: user.address,
      mobile: user.mobile
    }
    return this.http.post(this.rootUrl + 'user', body);
  }

  /* loginUser service called from loginUser method in signin component */
  loginUser(user: User) {
    const loginBody: UserLogin = {
      email: user.email,
      password: user.password
    }
    return this.http.post(this.rootUrl + 'login', loginBody);
  }

}
