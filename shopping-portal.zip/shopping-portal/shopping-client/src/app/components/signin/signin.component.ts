import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { UserLogin } from "../../shared/user.model";
import { UserService } from "../../shared/user.service";
import { Router } from "@angular/router";
import { DatasharingService } from "../../shared/datasharing.service";

@Component({
  selector: 'app-signin',
  templateUrl: './signin.component.html',
  styleUrls: ['./signin.component.css']
})

export class SigninComponent implements OnInit {

  userLogin: UserLogin;

  constructor(
    private datasharingService: DatasharingService,
    private userService: UserService,
    private router: Router
  ) { }

  ngOnInit(): void {
    this.resetForm();
  }

  /* Method to reset the form */
  resetForm(form?: NgForm) {
    if (form != null)
      form.reset();

    this.userLogin = {
      email: "",
      password: ""
    }
  }

  /* Method to register a user */
  loginUser(form: NgForm) {
    this.userService.loginUser(form.value)
      .subscribe((data: any) => {
        if (data.status === true) {
          alert(data.message);
          document.cookie = "token=" + data.result.token;
          this.datasharingService.isUserLoggedIn.next(true);
          this.router.navigate(['/home']);
        } else {
          alert(data.message);
        }
      });
  }

}
