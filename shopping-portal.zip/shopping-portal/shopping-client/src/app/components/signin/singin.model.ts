export class SignIn {

    email: string;
    password: string;

}