import { Component, OnInit } from '@angular/core';
import { Product } from '../../shared/product.model';
import { ProductService } from '../../shared/product.service';

@Component({
  selector: 'app-homepage',
  templateUrl: './homepage.component.html',
  styleUrls: ['./homepage.component.css']
})
export class HomepageComponent implements OnInit {

  product: Product;

  constructor(
    private productService: ProductService
  ) { }

  ngOnInit(): void {

  }

  placeOrder(productName, productPrice) {
    this.productService.placeOrder({ name: productName, price: productPrice })
      .subscribe((data: any) => {
        if (data.status === true) {
          alert(data.message);
        } else {
          alert(data.message);
        }
      });

  }

}
