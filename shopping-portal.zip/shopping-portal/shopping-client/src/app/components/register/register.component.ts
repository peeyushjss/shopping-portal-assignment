import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { User } from '../../shared/user.model';
import { UserService } from '../../shared/user.service';
import { Router } from "@angular/router";

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})

export class RegisterComponent implements OnInit {

  user: User;
  emailPattern = "^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$";

  constructor(
    private userService: UserService,
    private router: Router
  ) { }

  ngOnInit(): void {
    this.resetForm();
  }

  /* Method to reset the form */
  resetForm(form?: NgForm) {
    if (form != null)
      form.reset();

    this.user = {
      name: "",
      email: "",
      password: "",
      mobile: "",
      address: ""
    }
  }

  /* Method to register a user */
  registerUser(form: NgForm) {
    this.userService.registerUser(form.value)
      .subscribe((data: any) => {
        if (data.status === true) {
          alert(data.message);
          this.resetForm();
          this.router.navigate(['/signin']);
        } else {
          alert(data.message);
        }
      });
  }

}