export class Register {
    name: string;
    email: string;
    password: string;
    mobile: number;
    address: string;
}