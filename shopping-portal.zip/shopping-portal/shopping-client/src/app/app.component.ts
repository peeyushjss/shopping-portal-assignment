import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { DatasharingService } from './shared/datasharing.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  isUserLoggedIn: boolean;

  constructor(
    private datasharingService: DatasharingService,
    private router: Router
  ) {
    /* service for updating login and logout */
    this.datasharingService.isUserLoggedIn.subscribe(value => {
      this.isUserLoggedIn = value;
    });
  }

  ngOnInit(): void { }

  title = 'shopping-portal';

  delete_cookie(name) {
    document.cookie = name + '=;expires=Thu, 01 Jan 1970 00:00:01 GMT;';
  };

  /* Method to logout current user. Also delete cookie */
  logoutUser() {
    this.datasharingService.isUserLoggedIn.next(false);
    // this.isUserLoggedIn = false;
    this.delete_cookie('token');
    this.router.navigate(['/signin']);
  }

}
